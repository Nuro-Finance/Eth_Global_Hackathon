import { Pool } from "pg";

export const db = new Pool({
  connectionString: process.env.DATABASE_URL || "postgresql://cashly:cashly@localhost:5432/cashly_vaults",
});
